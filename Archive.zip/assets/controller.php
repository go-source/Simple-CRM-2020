<?php

/**
 * @version    CVS: 2.0.0
 * @package    Com_Gscrm20
 * @author     Pedro Bicudo Maschio <bicudomaschio@gmail.com>
 * @copyright  2021 Pedro Bicudo Maschio
 * @license    GNU General Public License version 3 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

/**
 * Gscrm20Controller class.
 * 
 * @extends JControllerLegacy
 */
class Gscrm20Controller extends JControllerLegacy
{
	//$name = gsComponent::gs_name();
	
	//JFactory::getApplication()->enqueueMessage($name);
   
}

